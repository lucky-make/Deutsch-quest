# DeutschQuest 🥨 — *Staffel 1: Ein Jahr in Köln*

An **offline-first German learning game** built as one running story: 12 episodes of
everyday ("essentials") German — Ankunft, Anmeldung, Supermarkt, Wohnung, Fieber, Job,
Bahnsteig, Briefe, Party, Notfall, Medien, *Bleibst du?* — from **A1 to B2**,
in the spirit of the free VHS-Lernportal courses, but as a narrative game.

Everything runs **client-side in a single HTML file**. No server, no database,
no internet needed after the page is loaded. Progress lives in `localStorage`.

## ▶ Play

- **GitHub Pages:** once deployed (see below), open `https://<your-user>.github.io/<repo>/`
- **Fully offline:** download/copy `index.html` anywhere and double-click it.
  Airplane mode works. USB stick works. WhatsApp-to-your-phone works.

## What makes it different

| Idea | Implementation |
|---|---|
| **Running narrative** | 12 episodes, one year in Köln, second person. Episodes unlock in order; each opens with a story scene and closes with a cliffhanger. Replay anytime. |
| **Essentials-only content** | Every card is everyday German: forms, Arzt, Pfand, Miete, Briefe & Fristen, Notfall-Nummern, Bahnsteig-Durchsagen, small talk, opinions — A1→B2 as the plot grows up. |
| **Law 1 · Retrieval, not review** | 9 mini-games, all production-first: type it (Free recall), see it (Bild-Karte with inline-SVG pictures), hear it (Hör-Profi, on-device voice), build it (Satzbau tiles), teach it (Professor-Modus), diagnose it (Fehler-Jagd). Multiple choice pays the least XP. |
| **Law 2 · Space until almost forgotten** | Leitner boxes 0–6 (now→10 min→1 d→3 d→7 d→21 d→60 d) + a fog meter; cards at 60–130 % fog queue first and pay a ×1.5 "desirable difficulty" bonus. |
| **Law 3 · Interleaving** | Kinds & mini-games shuffled every card; Fehler-Jagd forces you to decide *which* rule is broken before fixing it. |
| **Law 4 · Explain, source closed** | Professor-Modus: 45 s, out loud, plain language, honest self-rating. Peeking halves XP. |
| **Law 5 · Chunks, not facts** | Nouns carry their article, phrase frames are whole cards, sentences are tile-built. |
| **The review law** | Everything you miss returns: immediately (re-queued), then as 🔁 Wiederholung slots **inside later episodes** (4 per session, lapses first, tagged "🔁 Wiederholung · Ep. n"), plus a dedicated 🔁 Wiederholung mode across the whole story. |
| **Fun layer** | XP, combo multipliers, ranks (Neuling → Umlaut-Ultralord), day streaks, confetti, synth SFX — all generated on-device, zero assets. |

## Repository layout

```
index.html        the entire game (deck, story, scheduler, art, sound) — one file
docs/DESIGN.md    how it works: scheduler math, law→mechanic map, how to extend
LICENSE           MIT
```

## 🚀 Deploy to GitHub Pages (3 minutes)

**Option A — no git needed (browser only):**
1. Create a new **public** repository on github.com (e.g. `deutschquest`).
2. In the repo, click *uploading an existing file* and drop in `index.html`
   (optionally the whole repo folder), commit to `main`.
3. *Settings → Pages → Build and deployment → Source:* **Deploy from a branch**,
   branch **main**, folder **/(root)** → Save.
4. Copy your link: `https://<your-user>.github.io/<repo>/` ✅

**Option B — git:**
```bash
git remote add origin https://github.com/<your-user>/<repo>.git
git push -u origin main
```
then Settings → Pages as in step 3–4 above.

**Option C — enable Pages via API once the repo exists:**
```bash
curl -H "Authorization: Bearer $GITHUB_TOKEN" -H "Accept: application/vnd.github+json" \
  -X POST https://api.github.com/repos/<your-user>/<repo>/pages \
  -d '{"source":{"branch":"main","path":"/"}}'
```

> Pages needs the internet for the *first* load. For true offline play, keep a local
> copy of `index.html` — it is the whole product.

## ➕ Adding your own content

Open `index.html` and edit the two arrays at the top:

- `EPS` — episodes: `{n, title, lvl, intro, outro}` (the narrative).
- `DECK` — cards: `{id, ep, kind, de, en, …}` with `kind` ∈
  `word | chunk | sentence | grammar | error`.
  - `grammar` cards add `teach` (the out-loud prompt), `note` (model answer), `ex` (example sentence).
  - `error` cards add `errType` (must exist in `ERR_TYPES`), `fix`, `why`.
  - `word` cards can add `img: "<key>"` pointing into the inline-SVG library `IMG`
    (add your own key with a tiny `<svg>` body — stays offline, stays one file).

No build step, no dependencies. Save, reload, play.

## Learning-science source

The five laws come from a study-skills video (timestamps in the in-game
"🧠 The 5 laws" screen): retrieval practice (6:32), spacing-to-fog (8:00),
interleaving (9:03), teach-back with source closed (10:20), chunking — plus the
owner's review rule: *what you missed must come back, in later lessons.*

## License

MIT — see [LICENSE](LICENSE). Learn, fork, teach with it.
